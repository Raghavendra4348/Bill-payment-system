<!-- FOOTER -->
    <!-- <a href="#menu-toggle" class="btn btn-primary toggler" id="menu-toggle" style="z-index:1000;position:absolute;left:30px;bottom:0px"><i class="icon-circle-arrow-left"></i>Toggle DASH</a> -->
    <footer class="text-center">
        <div class="footer-below">
            <div class="container">
                Created by <a href="">BILLING </a> SYSTEM
            </div>
        </div>
    </footer>
